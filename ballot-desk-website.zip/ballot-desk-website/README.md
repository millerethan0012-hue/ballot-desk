# Ballot Desk — Website

A static, responsive 2026 midterm morning desk. No paid database or build framework is required.

## Preview locally
Because browsers block `fetch()` from `file://`, serve the folder locally:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Free hosting
Upload this folder to a GitHub repository and enable GitHub Pages, or deploy the folder to Cloudflare Pages.

## Data model
- `data/races.csv` — canonical race IDs
- `data/candidates.csv` — candidate ledger and status lock
- `data/ratings.csv` — rating history
- `data/polls.csv` — poll records; blank means the site says “No poll entered”
- `data/debates.csv` — debate state records
- `data/morning_brief.json` — daily editorial summary

The homepage displays only candidates with `ACTIVE_NOMINEE` status. Historical/deceased records stay in the ledger but are blocked from current race cards.

## Important
The seed data came from the user's corrected October 7 desk. It is not an automated live feed. Update/verify the data files before treating the page as a current election briefing.
